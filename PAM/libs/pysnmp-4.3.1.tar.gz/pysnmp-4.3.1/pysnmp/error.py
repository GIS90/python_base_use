class PySnmpError(Exception):
    pass
