.. toctree::
   :maxdepth: 2

Modifying variables
-------------------

.. include:: /../../examples/v1arch/asyncore/manager/cmdgen/v2c-set.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/v1arch/asyncore/manager/cmdgen/v2c-set.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/v1arch/asyncore/manager/cmdgen/v2c-set.py>` script.


See also: :doc:`library reference </docs/api-reference>`.
